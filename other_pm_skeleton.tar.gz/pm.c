//----------------------------------------------------------
//
// Project #3 : Other Page mapping FTLs
// 	- Embedded Systems Design, ICE3028 (Fall, 2018)
//
// Apr. 20, 2017.
//
// Dong-Yun Lee (dongyun.lee@csl.skku.edu)
// Jin-Soo Kim (jinsookim@skku.edu)
// Computer Systems Laboratory
// Sungkyunkwan University
// http://csl.skku.edu/ICE3028F18
//
//---------------------------------------------------------

#include "pm.h"
#include "nand.h"

#ifdef COST_BENEFIT
static long now(void) {
	return s.host_write + s.gc_write;
}
#endif


static void garbage_collection(void);

void ftl_open(void)
{
	return;
}

void ftl_read(long lpn, u32 *read_buffer)
{
	return;
}

void ftl_write(long lpn, u32 *write_buffer)
{
	return;
}

static void garbage_collection(void)
/***************************************
You can add some arguments and change
return type to anything you want
***************************************/
{
	s.gc++;


/***************************************
Add

s.gc_write++;

for every nand_write call (every valid page copy)
that you issue in this function
***************************************/

	return;
}
